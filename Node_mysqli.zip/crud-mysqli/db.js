var mysqli = require('mysql');

var conn = mysqli.createConnection({
	host:'localhost',
	user:'root',
	password:'',
	database:'node',
});

 conn.connect(function(err){

 	if(err) throw err;
 	console.log('database connect');
 });


module.exports = conn;