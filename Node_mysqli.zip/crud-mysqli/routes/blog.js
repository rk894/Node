var express = require('express');
var router = express.Router();
var multer = require('multer');

var storage = multer.diskStorage({

	destination: function(req,file,cb){  // cb == callback

		cb(null,'uploads/')  // path
	},
	filename: function(req,file,cb){
		cb(null, Date.now() + file.originalname)
	}

});

 var upload = multer({storage:storage}); 

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('image', { title: 'Express' });
});


 // single image upload


 // router.post('/upload',upload.single('image'),function(req,res,next){

 // 	var file=req.file.filename;
 // 	var name=req.body.fname;

 // 	console.log(file);
 // 	console.log(name);

 // 	res.send(file);
 // })


 // multipel image upload

                                      // how many file uploads 5
 router.post('/upload',upload.array('image',5),function(req,res,next){

 	var file=req.files.filename;
 	var name=req.body.fname;

 	// console.log(file);
 	// console.log(name);

 	// res.send(file);
 })





module.exports = router;
