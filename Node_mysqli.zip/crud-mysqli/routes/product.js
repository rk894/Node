var express = require('express');
var router = express.Router();
var db = require('../db');


/* GET home page. */
router.get('/', function(req, res, next) {
	var select ="select * from products";
	db.query(select, function(err,rows,fields){

		if(err) throw err;
		// res.json(rows);  // all data
		// res.json(rows[0]);  // single row
		// console.log(rows);

		res.render('product', { title: 'Products', data:rows });

	});
  
});

router.get('/form',function(req,res,next){

	res.render('form',{title:'Insert Data'});

});

router.post('/create',function(req,res,next){

	var pname=req.body.pname;
	var price=req.body.price;

	

	var sql=`insert into products values("","${pname}","${price}")`;

	// console.log(pname);
	db.query(sql,function(err,result){

		if(err) throw err;
		res.redirect('/product');

	});

	// console.log(req.body);

});

router.get('/edit/:id',function(req,res,next){

	var id=req.params.id;
	var sql = `select * from products where id=${id}`;
	db.query(sql,function(err,rows,fields){

		if(err) throw err;
		res.render('edit',{data:rows[0]});


	});


	router.post('/update',function(req,res,next){

		var pname=req.body.pname;
		var price=req.body.price;
		var id =req.body.id;

		var sql=`update products set name="${pname}",price="${price}" where id=${id}`;
		db.query(sql,function(err,result){

			if(err) throw err;
			res.redirect('/product');
		})

	});


	router.get('/delete/:id',function(req,res,next){

			var id=req.params.id;
	        var sql = `delete from products where id=${id}`;

		


		db.query(sql,function(err,result){

			
			res.redirect('/product');

			
		})

	});

	

});




module.exports = router;
