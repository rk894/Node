var express = require('express');
var router = express.Router();

/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/student/:id/:cid',function(req,res,next){

res.render('student',{data:req.params.cid});

});

router.post('/student/data',function(req,res,next){

	var fname=req.body.fname;
	var all=req.body;
	
	// res.render('data',{name:fname})
	res.render('data',{name:all})
});

module.exports = router;
