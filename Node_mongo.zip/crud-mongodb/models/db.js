
const mongoose= require("mongoose");

// automatically create database in mongodb

// without collection mongodb database is not visible , create at least one collection

//  to visible mongodb database

mongoose.connect("mongodb://localhost:27017/employee", { useNewUrlParser: true },(err)=>{

	if(!err){
		console.log("Mongodb connect");
	}
	else
	{
		console.log("Not connect"+err);

	}

});

require("./emp.model");