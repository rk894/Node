var mongoose = require('mongoose');

var empSchema = new mongoose.Schema({

	name:String,
	email:String,
	mobile:Number,
	address:String,

}); 

//automatically create emp  table in mongodb

var empModel= mongoose.model('emp',empSchema);

