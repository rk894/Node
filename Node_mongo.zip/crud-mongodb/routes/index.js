var express = require('express');
var mongoose = require('mongoose');

var router = express.Router();
var employee = mongoose.model('emp');

/* GET home page. */

router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});

router.get('/emp',function(req,res,next){

	res.render('employee');
	// res.send("ok");
});



router.post('/add',function(req,res,next){

	// console.log(req.body);

	var emp = new employee();
	emp.name=req.body.name;
	emp.email=req.body.email;
	emp.mobile=req.body.mobile;
	emp.address=req.body.address;

	emp.save((err,doc)=>{

		if(!err)
		{
			// console.log('ok');
			res.redirect('/show');

		}
		else
		{
			console.log(err);
		}

	});

	// res.send("ok");

});

router.get('/show',(req,res,next)=>{

	employee.find((err,docs)=>{
		if(!err)
		{
			// console.log(docs);
			res.render("show",{data:docs});
		}
	})

	

});

router.get('/edit/:id',(req,res,next)=>{

	employee.findById(req.params.id,(err,doc)=>{

		if(!err)
		{
			// console.log(doc);
			res.render('edit',{data:doc});
		}

	})
	
});

router.post('/update',(req,res,next)=>{

	employee.findOneAndUpdate({_id:req.body.id}, req.body, {new : true}, (err,doc)=>{

		if(!err)
		{
			 res.redirect('/show');
		}
		else
		{
			console.log(err);
			res.send(err);
		}
	})

});

router.get('/delete/:id',(req,res,next)=>{
	employee.findByIdAndDelete(req.params.id,(err,doc)=>{

		if(!err)
		{
			res.redirect('/show');
		}
		else
		{
			res.send(err);
		}

	})
})

module.exports = router;
